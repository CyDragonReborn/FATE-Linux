================================================================

Copyright � 1996-2012, Valve Corporation, All rights reserved.

================================================================


Welcome to the Steamworks SDK.  For documentation please see our partner 
website at: http://partner.steamgames.com


Revision History:

----------------------------------------------------------------
v1.24	17th July 2013
----------------------------------------------------------------

User:
* Added ISteamUser::GetBadgeLevel and ISteamUser::GetPlayerSteamLevel functions

Friends:
* Games can now initiate Steam Friend requests, removals, request -accepts and request-ignores via ISteamFriends� ActivateGameOverlayToUser API. This prompts the user for confirmation before action is taken.

Mac:
* Updated the OS X Content Prep tool and game wrapper for improved compatibility with OS X 10.8 (Mountain Lion).

Linux:
* Added install script for the Steam Linux Runtime tools (run "bash tools/linux/setup.sh" to install), see tools/linux/README.txt for details.
* SteamworksExample is now available on Linux

----------------------------------------------------------------
v1.23a	25th February 2013
----------------------------------------------------------------

Windows:
* Fix passing command-line parameters across SteamApi_RestartAppIfNeccessary()

----------------------------------------------------------------
v1.23	19th February 2013
----------------------------------------------------------------

Cloud:
* Added ISteamScreenshots::TagPublishedFile() which allows tagging workshop content that is visible or active when a screenshot is taken.
* Added ISteamRemoteStorage::UGCDownloadToLocation() which allows a developer to specify a location on disk to download workshop content.

Setup tool:
* Added Arabic to the supported languages for the PC Gold Master Setup Tool
* Fixed regression in localized EULA support in Mac OS X Gold Master Setup Tool

Windows:
* Fix SteamAPI_RestartAppIfNecessary() on 64 bit Windows
* When launching a game's development build from outside of Steam, fixed using steam_appid.txt in the Steam Overlay and for authorizing microtransactions (broken in the SDK 1.22)

Mac:
* Fixed many Steam callbacks not working for 64 bit OS X games due to mismatched structure alignment between the SDK and the Steam client
* Implemented SteamAPI_RestartAppIfNecessary()

Linux:
* Removed the need to redistribute libtier0_s.so and libvstdlib_s.so
* Fixed finding and loading steamclient.so, so LD_LIBRARY_PATH does not need to be set for game to talk with Steam
* Implemented SteamAPI_RestartAppIfNecessary()


----------------------------------------------------------------
v1.22	12th December 2012
----------------------------------------------------------------

Apps
* Added new API call ISteamApps::MarkContentCorrupt() so a game can hint Steam that some of it's local content seems corrupt. Steam will verify the content next time the game is started.
* Added new API call ISteamApps::GetCurrentBetaName() so a game can get the current content beta branch name if the user chose to opt-in to a content beta.

Cloud 
* Added an offset parameter to ISteamRemoteStorage::UGCRead() to allow reading files in chunks, and increased the limit from 100MB to 200MB when downloading files this way.

HTTP
* Added support for streaming HTTP requests with ISteamHTTP::SendHTTPRequestAndStreamResponse() and ISteamHTTP::GetHTTPStreamingResponseBodyData()

Linux
* Updated libsteam_api.so to find Steam in its new install location


----------------------------------------------------------------
v1.21	25th October 2012
----------------------------------------------------------------

Big Picture
* Added ISteamUtils::ShowGamepadTextInput() to enable usage of the Big Picture gamepad text input control in-game. UI is rendered by the Steam Overlay.
* Added ISteamUtils::GetEnteredGamepadTextLength() and ISteamUtils::GetEnteredGamepadTextInput() to retrieve entered gamepad text.
* Added GamepadTextInputDismissed_t callback to detect when the user has entered gamepad data.


----------------------------------------------------------------
v1.20	30th August 2012
----------------------------------------------------------------

SteamPipe
* Added local server and builder tools for new content system.

Mac
* OSX Supports 64 bit build targets.
* Spacewar has been updated to be buildable as a 64 bit OSX sample application.

Friends
* Added a callback for the result of ISteamFriends::SetPersonaName().
* Changed ISteamFriends::ActivateGameOverlayToStore() to take an additional parameter so app can be directly added to the cart.

Cloud
* Added ISteamRemoteStorage::FileWriteStreamOpen(), FileWriteStreamWriteChunk(), FileWriteStreamClose() and FileWriteStreamCancel() for streaming operations.
* Changed parameters to ISteamRemoteStorage::PublisheVideo().
* Added file type to ISteamRemoteStorage::GetPublishedFileDetails() callback result (RemoteStorageGetPublishedFileDetailsResult_t).
* Added a callback to indicate that a published file that a user owns was deleted (RemoteStoragePublishedFileDeleted_t).

ISteamUserStats
* Added ISteamUserStats::GetNumAchievements() and ISteamUserStats::GetAchievementName().


----------------------------------------------------------------
v1.19	22nd March 2012
----------------------------------------------------------------

Friends
* Added ISteamFriends::GetFollowerCount()
* Added ISteamFriends::IsFollowing()
* Added ISteamFriends::EnumerateFollowingList()

Cloud
* Added ISteamRemoteStorage::UpdatePublishedFileSetChangeDescription()
* Added ISteamRemoteStorage::GetPublishedItemVoteDetails()
* Added ISteamRemoteStorage::UpdateUserPublishedItemVote()
* Added ISteamRemoteStorage::GetUserPublishedItemVoteDetails()
* Added ISteamRemoteStorage::EnumerateUserSharedWorkshopFiles()
* Added ISteamRemoteStorage::PublishVideo()
* Added ISteamRemoteStorage::SetUserPublishedFileAction()
* Added ISteamRemoteStorage::EnumeratePublishedFilesByUserAction()
* Added ISteamRemoteStorage::EnumeratePublishedWorkshopFiles()

ISteamGameServer
* Updated callback for SteamGameServer::ComputeNewPlayerCompatibility to include the steam id the compatibility was calculated for


----------------------------------------------------------------
v1.18	7th February 2012
----------------------------------------------------------------

Cloud
* Removed ISteamRemoteStorage::PublishFile() and consolidated the API to PublishWorkshopFile()
* Updated ISteamRemoteStorage::PublishWorkshopFile() to better define the type of workshop file being published
* Replaced ISteamRemoteStorage::UpdatePublishedFile() with a new mechanism to update existing files through CreatePublishedFileUpdateRequest() UpdatePublishedFile[Property](), and CommitPublishedFileUpdate()
* Increased the description field for a workshop file from 256 -> 8000 characters
* Added ISteamRemoteStorage::GetUGCDownloadProgress()
* Added file size limit of 100MB to ISteamRemoteStorage::FileWrite()

Apps:
* Added ISteamApps::RequestAppProofOfPurchaseKey

----------------------------------------------------------------
v1.17	2nd November 2011
----------------------------------------------------------------

Cloud
* Added ISteamRemoteStorage::PublishFile(), PublishWorkshopFile(), UpdatePublishedFile(), DeletePublishedFile() which enables sharing, updating, and unsharing of cloud content with the Steam community
* Added ISteamRemoteStorage::EnumerateUserPublishedFiles to enumerate content that a user has shared with the Steam community
* Added ISteamRemoteStorage::GetPublishedFileDetails() which gets the metadata associated with a piece of community shared content
* Added ISteamRemoteStorage::SubscribePublishedFile(), EnumerateUserSubscribedFiles(), and UnsubscribePublishedFiles() which allow for management of community content that a user is interested in and marked as a favorite

User
* Updated ISteamUser::GetAuthSessionTicket(), When creating a ticket for use by the AuthenticateUserTicket Web API, the calling application should wait for the callback GetAuthSessionTicketResponse_t generated by the API call before attempting to use the ticket to ensure that the ticket has been communicated to the server. If this callback does not come in a timely fashion ( 10 - 20 seconds ), your client is not connected to Steam, and the AuthenticeUserTicket will fail because it can not authenticate the user.

Friends
* Added ISteamFriends::RequestFriendRichPresence, which allows requesting rich presence keys for any Steam user playing the same game as you
* Added a set of functions to ISteamFriends which allow games to integrate with Steam Chat. Games can both join group chats, as well as get friends chats and show them in-line in the game. This API isn�t currently used in a game, so there may be some rough edges around the user experience to work out, and some experimentation is required.

Game Servers
* Removed the ISteamMasterServerUpdater interface.  It has been merged into the ISteamGameServer interface, which is used to communicate all game server state changes.
* Significant changes to the game server init sequence.  (See the comments for SteamGameServer_Init  and the ISteamGameServer interface.)
* Removed interface to legacy master server mode
* Groundwork for implementing named steam accounts for game servers
* Old player auth system is deprecated.  It may be removed in a future version of the SDK.

Tools
* Added tool for automated DRM submissions in /sdk/tools/drm/

----------------------------------------------------------------
v1.16	29th July 2011
----------------------------------------------------------------

HTTP
* added ISteamHTTP::SetHTTPRequestRawPostBody() to set the raw body of a POST request
Screenshots
* added ISteamScreenshots interface, which enables adding screenshots to the user's screenshot library and tagging them with location data or relevant players that are visible in the screenshot.  A game can provide screenshots based on game events using WriteScreenshot, AddScreenshotToLibrary, or TriggerScreenshot.  A game can also choose to provide its own screenshots when the Steam screenshot hotkey is pressed by calling HookScreenshots() and listening for the ScreenshotRequested_t callback.

----------------------------------------------------------------
v1.15	1st June 2011
----------------------------------------------------------------

Bug fixes
* Fixed exposing HTTP interface
* Fixed setting AppID for game processes started outside of Steam or which require administrative privileges


----------------------------------------------------------------
v1.14	16th May 2011
----------------------------------------------------------------

Stats and Achievements
* Added a set of functions for accessing global achievement unlock percentages
** RequestGlobalAchievementPercentages() to request the completion percentages from the backend
** GetMostAchievedAchievementInfo() and GetNextMostAchievedAchievementInfo() to iterate achievement completion percentages
** GetAchievementAchievedPercent() to query the global unlock percentage for a specific achievement
* Added a set of functions for accessing global stats values. To enable a global stats set stats as "aggregated" from the Steamworks admin page.
** RequestGlobalStats() to request the global stats data from the backend
** GetGlobalStat() to get the global total for a stat
** GetGlobalStatHistory() to get per day totals for a stat

HTTP
* added ISteamHTTP::GetHTTPDownloadProgressPct() get the progress of an HTTP request


----------------------------------------------------------------
v1.13	26th April 2011
----------------------------------------------------------------

Rich Presence
* added a new Rich Presence system to allow for sharing game specific per user data between users
* ISteamFriends::SetRichPresense() can be used to set key/value presence data for the current user
* ISteamFriends::GetFriendRichPresence() and related functions can be used to retrieve presence data for a particular user
* Two special presence keys exist:
** the "connect" key can be set to specify a custom command line used by friends when joining that user
** the "status" key can be set to specify custom text that will show up in the 'view game info' dialog in the Steam friends list

HTTP
* added ISteamHTTP, which exposes methods for making HTTP requests

Downloadable Content
* added ISteamApps::GetDLCCount() and ISteamApps::BGetDLCDataByIndex() to allow for enumerating DLC content for the current title
* added ISteamApps::InstallDLC() and ISteamApps::UninstallDLC() to control installing optional content

P2P Networking
* added ISteamNetworking::CloseP2PChannelWithUser(), to allow for closing a single channel to a user. When all channels are closed, the connection to that user is automatically closed.
* added ISteamNetworking::AllowP2PPacketRelay(), which can be used to prevent allowing P2P connections from falling back to relay

Voice
* ISteamUser::GetAvailableVoice() & ISteamUser::GetVoice() now take the desired sample rate to determine the number of uncompressed bytes to return
* added ISteamUser::GetVoiceOptimalSampleRate() to return the frequency of the voice data as it's stored internally

Friends
* added ISteamFriends methods to retrieve the list of users the player has recently played with

Content Tool
* all files are now encrypted by default
* add command line option to app creation wizard
* add command line edit option by right clicking on app
* update cache size in CDDB after each build
* look for install scripts at build time and automatically add CDDB flag
* fix language names for chinese
* add menu button to easily rev version
* warn if rebuilding existing version
* allow specifying subfolder when ftp-ing depots to valve
* better error messaging if ftp fails
* clean up various small display bugs
* don't trash ValidOSList tag when updating CDDB

OSX DirectX to OpenGL
* added the graphics layer used to port Valve games to OSX which can now be used by all Steamworks developers
* included in the Steamworks Example application. Can be enabled by building with DX9MODE=1


----------------------------------------------------------------
v1.12	10th November 2010
----------------------------------------------------------------

Cloud
* added a set of function to handle publishing User Generated Content (UGC) files to the backend, and to download others users UGC files. This enables games to have users easily publish & share content with each other.
* Added ISteamRemoteStorage::FileForget() which tells a file to remain on disk but to be removed from the backend. This can be used to manage which files should be synchronized if you have more files to store than your quota allows.
* Added ISteamRemoteStorage::FilePersisted() to tell if the file is set to be synchronized with the backend.
* Added ISteamRemoteStorage::FileDelete() which tells a file to be deleted locally, from cloud, and from other clients that have the file. This can be used to properly delete a save file rather than writing a 1-byte file as a sentinel.
* Added ISteamRemoteStorage::SetSyncPlatforms(), GetSyncPlatforms() to tell steam which platforms a file should be synchronized to. This allows OSX not to download PC-specific files, or vice-versa.
* Added ISteamRemoteStorage::IsCloudEnabledForAccount(), IsCloudEnabledForApp(), and SetCloudEnabledForApp(). When cloud is disabled the APIs still work as normal and an alternate location on disk is not needed. It just means the files will not be synchronized with the backend.

Leaderboards
* added ISteamUserStats::DownloadLeaderboardEntriesForUsers(), which downloads scores for an arbitrary set of users
* added ISteamUserStats::AttachLeaderboardUGC(), to attach a clouded file to a leaderboard entry

Friends
* added ISteamFriends::RequestUserInformation(), to asynchronously request a users persona name & avatar by steamID
* added ISteamFriends::RequestClanOfficerList(), to asynchronously download the set of officers for a clan. GetClanOwner(), GetClanOfficerCount(), and GetClanOfficerByIndex() can then be used to access the data.

Matchmaking
* added k_ELobbyTypePrivate option to creating lobbies - this means that the lobby won't show up to friends or be returned in searches
* added LobbyDataUpdate_t::m_bSuccess, to easily check if a RequestLobbyData() call failed to find the specified lobby

Authentication
* added ISteamApps::GetEarliestPurchaseUnixTime(), for games that want to reward users who have played for a long time
* added ISteamApps::BIsSubscribedFromFreeWeekend(), so games can show different offers or information for users who currently only have rights to play the game due to a free weekend promotion
* added ISteamGameServer::GetAuthSessionTicket(), BeginAuthSession(), EndAuthSession(), and CancelAuthTicket(), matching what exists in ISteamUser. This allows game servers and clients to authenticate each other in a unified manner.

OSX
* The Steamworks Spacewar example now builds/runs on OS X
* The OSX retail install setup application is now contained in goldmaster\disk_assets\SteamRetailInstaller.dmg

PS3
* added several functions regarding PS3 support. This is still a work in progress, and no PS3 binaries are included.


----------------------------------------------------------------
v1.11	23rd August 2010
----------------------------------------------------------------

Networking
* added virtual ports to the P2P networking API to help with routing messages to different systems
* added ISteamUser::BIsBehindNAT() to detect when a user is behind a NAT

Friends / Matchmaking
* added support for retrieving large (184x184) avatars
* added ISteamUser::AdvertiseGame() which can be used send join game info to friends without using the game server APIs

64-bit support
* 64-bit windows binaries are included in the sdk/redistributable_bin/ folder
* VAC and CEG are not yet supported

Authentication
* added ticket based remote authentication library

Other
* added ISteamUser::CheckFileSignature which can be used in conjunction with the signing tab on the partner site to verify that an executable has not been modified


----------------------------------------------------------------
v1.10	20th July 2010
----------------------------------------------------------------

Friends / Matchmaking
* added function ISteamFriends::GetClanTag(), which returns the abbreviation set for a group
* added "stats" and "achievements" options to ISteamFriends::ActivateGameOverlayToUser()
* added function ISteamFriends::ActivateGameOverlayInviteDialog() to open the invite dialog for a specific lobby
* renamed ISteamMatchmaking::SetGameType() to the more correct SetGameTags()

Authentication
* added ISteamUtils::CheckFileSignature(), which can be used to verify that a binary has a valid signature

Other
* added #pragma pack() in several places around structures in headers


----------------------------------------------------------------
v1.09	12th May 2010
----------------------------------------------------------------

Mac Steamworks!
* new binaries in the sdk/redistributable_bin/osx/ folder

Other
* explicit pragma( pack, 8 ) added around all callbacks and structures, for devs who have use a different default packing
* renamed function ISteamGameServer::SetGameType() to the more accurate ISteamGameServer::SetGameTags()


----------------------------------------------------------------
v1.08	27st January 2010
----------------------------------------------------------------

Matchmaking
* added function ISteamMatching::AddRequestLobbyListDistanceFilter(), to specify how far geographically you want to search for other lobbies
* added function ISteamMatching::AddRequestLobbyListResultCountFilter(), to specify how the maximum number of lobby you results you need (less is faster)

Stats & Achievements
* added interface ISteamGameServerStats, which enables access to stats and achievements for users to the game server
* removed function ISteamGameServer::BGetUserAchievementStatus(), now handled by ISteamGameServerStats
* added ISteamUserStats::GetAchievementAndUnlockTime(), which returns if and when a user unlocked an achievement

Other
* added new constant k_cwchPersonaNameMax (32), which is the maximum number of unicode characters a users name can be
* removed ISteamRemoteStorage::FileDelete() - NOTE: it will be back, it's only removed since it hadn't been implemented on the back-end yet
* added function ISteamGameServer::GetServerReputation(), gives returns a game server reputation score based on how long users typically play on the server


----------------------------------------------------------------
v1.07	16th December 2009
----------------------------------------------------------------

* Replaced SteamAPI_RestartApp() with SteamAPI_RestartAppIfNecessary(). This new function detects if the process was started through Steam, and starts the current game through Steam if necessary.
* Added ISteamUtils::BOverlayNeedsPresent() so games with event driven rendering can determine when the Steam overlay needs to draw


----------------------------------------------------------------
v1.06	30th September 2009
----------------------------------------------------------------

Voice
* ISteamUser::GetCompressedVoice() has been replaced with ISteamUser::GetVoice which can be used to retrieve compressed and uncompressed voice data
* Added ISteamUser::GetAvailableVoice() to retrieve the amount of captured audio data that is available

Matchmaking
* Added a new callback LobbyKicked_t that is sent when a user has been disconnected from a lobby
* Through ISteamMatchmakingServers, multiple server list requests of the same type can now be outstanding at the same time

Steamworks Setup Application:
* Streamlined configuration process
* Now supports EULAs greater than 32k bytes

Content Tool
* Added DLC checkbox to depot creation wizard

Other
* Added SteamAPI_IsSteamRunning()
* Added SteamAPI_RestartApp() so CEG users can restart their game through Steam if launched through Windows Games Explorer



----------------------------------------------------------------
v1.05	11th June 2009
----------------------------------------------------------------

Matchmaking
* Added the SteamID of the gameserver to the gameserveritem_t structure (returned only by newer game servers)
* Added ISteamUserStats::GetNumberOfCurrentPlayers(), asyncronously returns the number users currently running this game
* Added k_ELobbyComparisonNotEqual comparision functions for filters
* Added option to use comparison functions for string filters
* Added ISteamMatchmaking::AddRequestLobbyListFilterSlotsAvailable( int nSlotsAvailable ) filter function, so you can find a lobby for a group of users to join
* Extended ISteamMatchmaking::CreateLobby() to take the max number of users in the lobby
* Added ISteamMatchmaking::GetLobbyDataCount(), ISteamMatchmaking::GetLobbyDataByIndex() so you can iterate all the data set on a lobby
* Added ISteamMatchmaking::DeleteLobbyData() so you can clear a key from a lobby
* Added ISteamMatchmaking::SetLobbyOwner() so that ownership of a lobby can be transferred
* Added ISteamMatchmaking::SetLobbyJoinable()
* Added ISteamGameServer::SetGameData(), so game server can set more information that can be filtered for in the server pinging API

Networking
* Added a set of connectionless networking functions for easy use for making peer-to-peer (NAT traversal) connections. Includes supports for windowed reliable sendsand fragementation/re-assembly of large packets. See ISteamNetworking.h for more details.

Leaderboards
* Added enum ELeaderboardUploadScoreMethod and changed ISteamUserStats::UploadLeaderboardScore() to take this - lets you force a score to be changed even if it's worse than the prior score

Callbacks
* Added CCallbackManual<> class to steam_api.h, a version of CCallback<> that doesn't register itself automatically in it's the constructor

Downloadable Content
* Added ISteamUser::UserHasLicenseForApp() and ISteamGameServer::UserHasLicenseForApp() to enable checking if a user owns DLC in multiplayer. See the DLC documentation for more info.

Game Overlay
* ISteamFriends::ActivateGameOverlay() now accepts "Stats" and "Achievements"



----------------------------------------------------------------
v1.04	9th Mar 2009
----------------------------------------------------------------

Added Peer To Peer Multi-Player Authentication/Authorization:
* Allows each peer to verify the unique identity of the peers ( by steam account id ) in their game and determine if that user is allowed access to the game.
* Added to the ISteamUser interface: GetAuthSessionTicket(), BeginAuthSession(), EndAuthSession() and CancelAuthTicket()
* Additional information can be found in the API Overview on the Steamworks site

Added support for purchasing downloadable content in game:
* Added ISteamApps::BIsDlcInstalled() and the DlcInstalled_t callback, which enable a game to check if downloadable content is owned and installed
* Added ISteamFriends::ActivateGameOverlayToStore(), which opens the Steam game overlay to the store page for an appID (can be a game or DLC)

Gold Master Creation:
* It is no longer optional to encrypt depots on a GM
* The GM configuration file now supports an included_depots key, which along with the excluded_depots key, allows you to specify exactly which depots are placed on a GM
* Simplified the configuration process for the setup application
* The documentation for creating a Gold Master has been rewritten and extended. See the Steamworks site for more information.

Added Leaderboards:
* 10k+ leaderboards can now be created programmatically per game, and queried globally or compared to friends
* Added to ISteamUserStats interface
* See SteamworksExample for a usage example

Other:
* Added SteamShutdown_t callback, which will alert the game when Steam wants to shut down
* Added ISteamUtils::IsOverlayEnabled(), which can be used to detect if the user has disabled the overlay in the Steam settings
* Added ISteamUserStats::ResetAllStats(), which can be used to reset all stats (and optionally achievements) for a user
* Moved SetWarningMessageHook() from ISteamClient to ISteamUtils
* Added SteamAPI_SetTryCatchCallbacks,  sets whether or not Steam_RunCallbacks() should do a try {} catch (...) {} around calls to issuing callbacks
* In CCallResult callback, CCallResult::IsActive() will return false and can now reset the CCallResult
* Added support for zero-size depots
* Properly strip illegal characters from depot names



----------------------------------------------------------------
v1.03	16th Jan 2009
----------------------------------------------------------------

Major changes:
* ISteamRemoteStorage interface has been added, which contains functions to store per-user data in the Steam Cloud back-end. 
** To use this, you must first use the partner web site to enable Cloud for your game. 
** The current setting is allowing 1MB of storage per-game per-user (we hope to increase this over time).

Lobby & Matchmaking related changes:
* ISteamFriends::GetFriendGamePlayed() now also return the steamID of the lobby the friend is in, if any. It now takes a pointer to a new FriendGameInfo_t struct, which it fills 
* Removed ISteamFriends::GetFriendsLobbies(), since this is now redundant to ISteamFriends::GetFriendGamePlayed()
* Added enum ELobbyComparison, to set the comparison operator in ISteamMatchmaking::AddRequestLobbyListNumericalFilter()
* Changed ISteamMatchmaking::CreateLobby(), JoinLobby() and RequestLobbyList() to now return SteamAPICall_t handles, so you can easily track if a particular call has completed (see below)
* Added ISteamMatchmaking::SetLobbyType(), which can switch a lobby between searchable (public) and friends-only
* Added ISteamMatchmaking::GetLobbyOwner(), which returns the steamID of the user who is currently the owner of the lobby. The back-end ensures that one and only one user is ever the owner. If that user leaves the lobby, another user will become the owner.

Steam game-overlay interaction:
* Added a new callback GameLobbyJoinRequested_t, which is sent to the game if the user selects 'Join friends game' from the Steam friends list, and that friend is in a lobby. The game should initiate connection to that lobby.
* Changed ISteamFriends::ActivateGameOverlay() can now go to "Friends", "Community", "Players", "Settings", "LobbyInvite", "OfficialGameGroup"
* Added ISteamFriends::ActivateGameOverlayToUser(), which can open a either a chat dialog or another users Steam community profile
* Added ISteamFriends::ActivateGameOverlayToWebPage(), which opens the Steam game-overlay web browser to the specified url

Stats system changes:
* Added ISteamUserStats::RequestUserStats(), to download the current game stats of another user
* Added ISteamUserStats::GetUserStat() and ISteamUserStats::GetUserAchievement() to access the other users stats, once they've been downloaded

Callback system changes:
* Added new method for handling asynchronous call results, currently used by CreateLobby(), JoinLobby(), RequestLobbyList(), and RequestUserStats(). Each of these functions returns a handle, SteamAPICall_t, that can be used to track the completion state of a call.
* Added new object CCallResult<>, which can map the completion of a SteamAPICall_t to a function, and include the right data. See SteamworksExample for a usage example.
* Added ISteamUtils::IsAPICallCompleted(), GetAPICallFailureReason(), and GetAPICallResult(), which can be used to track the state of a SteamAPICall_t (although it is recommended to use CCallResult<>, which wraps these up nicely)

Other:
* Added ISteamGameServer::GetPublicIP(), which is the IP address of a game server as seen by the Steam back-end
* Added "allow relay" parameter to ISteamNetworking::CreateP2PConnectionSocket() and CreateListenSocket(), which specified if being bounced through Steam relay servers is OK if a direct p2p connection fails (will have a much higher latency, but increases chance of making a connection)
* Added IPCFailure_t callback, which will be posted to the game if Steam itself has crashed, or if Steam_RunCallbacks() hasn't been called in a long time



----------------------------------------------------------------
v1.02	4th Sep 2008
----------------------------------------------------------------

The following interfaces have been updated:

ISteamUser

	// Starts voice recording. Once started, use GetCompressedVoice() to get the data
	virtual void StartVoiceRecording( ) = 0;

	// Stops voice recording. Because people often release push-to-talk keys early, the system will keep recording for
	// a little bit after this function is called. GetCompressedVoice() should continue to be called until it returns
	// k_eVoiceResultNotRecording
	virtual void StopVoiceRecording( ) = 0;

	// Gets the latest voice data. It should be called as often as possible once recording has started.
	// nBytesWritten is set to the number of bytes written to pDestBuffer. 
	virtual EVoiceResult GetCompressedVoice( void *pDestBuffer, uint32 cbDestBufferSize, uint32 *nBytesWritten ) = 0;

	// Decompresses a chunk of data produced by GetCompressedVoice(). nBytesWritten is set to the 
	// number of bytes written to pDestBuffer. The output format of the data is 16-bit signed at 
	// 11025 samples per second.
	virtual EVoiceResult DecompressVoice( void *pCompressed, uint32 cbCompressed, void *pDestBuffer, uint32 cbDestBufferSize, uint32 *nBytesWritten ) = 0;

virtual int InitiateGameConnection( void *pAuthBlob, int cbMaxAuthBlob, CSteamID steamIDGameServer, uint32 unIPServer, uint16 usPortServer, bool bSecure ) = 0;

This has been extended to be usable for games that don't use the other parts of Steamworks matchmaking. This allows any multiplayer game to easily notify the Steam client of the IP:Port of the game server the user is connected to, so that their friends can join them via the Steam friends list. Empty values are taken for auth blob.

            virtual bool GetUserDataFolder( char *pchBuffer, int cubBuffer ) = 0;

This function returns a hint as a good place to store per- user per-game data.



ISteamMatchmaking

Added a set of server-side lobby filters, as well as voice chat, lobby member limits, and a way of quickly accessing the list of lobbies a users friends are in.

      // filters for lobbies
      // this needs to be called before RequestLobbyList() to take effect
      // these are cleared on each call to RequestLobbyList()
      virtual void AddRequestLobbyListFilter( const char *pchKeyToMatch, const char *pchValueToMatch ) = 0;
      // numerical comparison - 0 is equal, -1 is the lobby value is less than nValueToMatch, 1 is the lobby value is greater than nValueToMatch
      virtual void AddRequestLobbyListNumericalFilter( const char *pchKeyToMatch, int nValueToMatch, int nComparisonType /* 0 is equal, -1 is less than, 1 is greater than */ ) = 0;
      // sets RequestLobbyList() to only returns lobbies which aren't yet full - needs SetLobbyMemberLimit() called on the lobby to set an initial limit
      virtual void AddRequestLobbyListSlotsAvailableFilter() = 0;

      // returns the details of a game server set in a lobby - returns false if there is no game server set, or that lobby doesn't exist
      virtual bool GetLobbyGameServer( CSteamID steamIDLobby, uint32 *punGameServerIP, uint16 *punGameServerPort, CSteamID *psteamIDGameServer ) = 0;

      // set the limit on the # of users who can join the lobby
      virtual bool SetLobbyMemberLimit( CSteamID steamIDLobby, int cMaxMembers ) = 0;
      // returns the current limit on the # of users who can join the lobby; returns 0 if no limit is defined
      virtual int GetLobbyMemberLimit( CSteamID steamIDLobby ) = 0;

      // asks the Steam servers for a list of lobbies that friends are in
      // returns results by posting one RequestFriendsLobbiesResponse_t callback per friend/lobby pair
      // if no friends are in lobbies, RequestFriendsLobbiesResponse_t will be posted but with 0 results
      // filters don't apply to lobbies (currently)
      virtual bool RequestFriendsLobbies() = 0;


ISteamUtils
      // Sets the position where the overlay instance for the currently calling game should show notifications.
      // This position is per-game and if this function is called from outside of a game context it will do nothing.
      virtual void SetOverlayNotificationPosition( ENotificationPosition eNotificationPosition ) = 0;


ISteamFriends
            virtual int GetFriendAvatar( CSteamID steamIDFriend, int eAvatarSize ) = 0;

This function now takes an eAvatarSize parameter, which can be k_EAvatarSize32x32 or k_EAvatarSize64x64 (previously it always just returned a handle to the 32x32 image)


----------------------------------------------------------------
v1.01  	8th Aug 2008
----------------------------------------------------------------

The Steamworks SDK has been updated to simplfy game server authentication and better expose application state


----------------------------------------------------------------
v1.0:
----------------------------------------------------------------

- Initial Steamworks SDK release
